package com.example.weeklyring

import android.content.Intent
import android.content.SharedPreferences
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Weekly Ring — fully offline.
 * No network calls are made anywhere in this app; all data (which ringtone
 * is assigned to which day) is stored locally in SharedPreferences on-device.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private val days = arrayOf(
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    )
    private var pendingDayKey: String? = null
    private val subtitleViews = mutableMapOf<String, TextView>()

    private val ringtonePickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            val key = pendingDayKey
            if (key != null) {
                prefs.edit().putString(key, uri?.toString() ?: "").apply()
                updateSubtitle(key)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("weekly_ring_prefs", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 72, 48, 72)
        }

        root.addView(TextView(this).apply {
            text = "Weekly Ring"
            textSize = 26f
            setPadding(0, 0, 0, 8)
        })

        root.addView(TextView(this).apply {
            text = "Assign a ringtone to each day. Everything is stored on this device only — the app has no internet permission and makes no network calls."
            textSize = 14f
            setPadding(0, 0, 0, 24)
        })

        root.addView(Button(this).apply {
            text = "Step 1 — Allow ringtone changes"
            setOnClickListener {
                if (!Settings.System.canWrite(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } else {
                    text = "✓ Permission already granted"
                }
            }
        })

        root.addView(TextView(this).apply {
            text = "\nStep 2 — Choose each day's ringtone"
            textSize = 16f
            setPadding(0, 16, 0, 8)
        })

        for (dayName in days) {
            val key = "ringtone_$dayName"

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 24, 0, 24)
            }

            row.addView(TextView(this).apply {
                text = dayName
                textSize = 18f
            })

            val sub = TextView(this).apply {
                text = currentRingtoneLabel(key)
                textSize = 12f
                alpha = 0.7f
            }
            subtitleViews[key] = sub
            row.addView(sub)

            row.addView(Button(this).apply {
                text = "Choose ringtone"
                setOnClickListener { launchPicker(key) }
            })

            root.addView(row)
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun launchPicker(key: String) {
        pendingDayKey = key
        val existing = prefs.getString(key, null)
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            if (!existing.isNullOrEmpty()) {
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existing))
            }
        }
        ringtonePickerLauncher.launch(intent)
    }

    private fun currentRingtoneLabel(key: String): String {
        val uriStr = prefs.getString(key, null)
        if (uriStr.isNullOrEmpty()) return "Not set — will use your phone's default"
        return try {
            val ringtone = RingtoneManager.getRingtone(this, Uri.parse(uriStr))
            "Set to: " + ringtone.getTitle(this)
        } catch (e: Exception) {
            "Not set — will use your phone's default"
        }
    }

    private fun updateSubtitle(key: String) {
        subtitleViews[key]?.text = currentRingtoneLabel(key)
    }
}
