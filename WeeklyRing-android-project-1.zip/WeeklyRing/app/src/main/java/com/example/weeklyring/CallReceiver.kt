package com.example.weeklyring

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import android.telephony.TelephonyManager
import java.util.Calendar

/**
 * Listens for the phone entering the RINGING state and, if the user has
 * assigned a ringtone to the current day, sets it as the active system
 * ringtone just before the call rings through.
 *
 * This never touches the network — it only reads local SharedPreferences
 * and calls into the on-device RingtoneManager.
 */
class CallReceiver : BroadcastReceiver() {

    private val dayNames = arrayOf(
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    )

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        // Requires the user to have granted "Modify system settings" in Step 1.
        if (!Settings.System.canWrite(context)) return

        val dayIndex = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1 // Calendar: 1=Sunday
        val key = "ringtone_${dayNames[dayIndex]}"

        val prefs = context.getSharedPreferences("weekly_ring_prefs", Context.MODE_PRIVATE)
        val uriStr = prefs.getString(key, null)
        if (uriStr.isNullOrEmpty()) return // no custom tone assigned, leave default alone

        try {
            val uri = Uri.parse(uriStr)
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, uri)
        } catch (e: Exception) {
            // Fail silently — the call will simply ring with whatever tone was already set.
        }
    }
}
